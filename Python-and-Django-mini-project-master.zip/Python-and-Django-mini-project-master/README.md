# Python-and-Django-mini-project
I was teaching myself python. So I created a mini django app with python. It is a hospital app that allows a person to book a consultation and appointment.
